# TEEEM Claude Code Configuration

Optimized Claude Code setup designed to reduce hallucination and improve reliability.

## Structure

```
├── CLAUDE.md                    # Main instructions (~50 lines, not 800)
├── TEEEM_DOCS/
│   ├── COMPONENTS.md            # UI component SSoT
│   ├── DEPLOY.md                # Deployment guide
│   ├── DEBUGGING.md             # Token-efficient debugging
│   └── GOLD_STANDARD_TABLE.md   # (keep your existing one)
└── .claude/
    ├── settings.json            # Permissions + hooks
    └── skills/
        ├── ssot-auditor/SKILL.md
        ├── product-planner/SKILL.md
        └── ui-compliance/SKILL.md
```

## What Changed

### 1. Slim CLAUDE.md
- Old: ~800 lines of instructions, philosophy, examples
- New: ~50 lines of essential rules + pointers to docs
- Why: Claude can reliably follow ~150 instructions max. Less is more.

### 2. Progressive Disclosure
- Details live in `TEEEM_DOCS/` - Claude reads them *when relevant*
- Skills have frontmatter so Claude auto-discovers them based on context
- Reduces token waste on irrelevant context

### 3. Anti-Hallucination Patterns
- "When uncertain, STOP and ask" is the first rule
- Skills require verification steps (grep checks, typecheck)
- Hooks block git operations by default

### 4. Skills Replace Agents
- Old `agents/` folder → new `skills/` folder
- Proper frontmatter with `name` and `description`
- Claude auto-invokes based on task context

## Installation

```bash
# Backup existing config
mv ~/Teeem/CLAUDE.md ~/Teeem/CLAUDE.md.backup
mv ~/Teeem/.claude ~/Teeem/.claude.backup

# Copy new config
cp -r teeem-claude-config/CLAUDE.md ~/Teeem/
cp -r teeem-claude-config/TEEEM_DOCS/* ~/Teeem/TEEEM_DOCS/
cp -r teeem-claude-config/.claude/* ~/Teeem/.claude/

# Keep your existing GOLD_STANDARD_TABLE.md - don't overwrite it
```

## Migration Notes

1. **Keep your existing `GOLD_STANDARD_TABLE.md`** - this config references it but doesn't replace it

2. **Review settings.json** - adjust permissions for your workflow

3. **Test the hooks** - try `git commit` in Claude Code, should be blocked

4. **Old agents/** - you can keep them as reference, but skills/ is now the active folder

## Keywords That Trigger Behavior

| Keyword | What Happens |
|---------|-------------|
| `ssot` | Claude searches for duplicates, shows both, asks which is truth |
| `ultra` | Claude presents 3 approaches before coding |
| `gold` | Claude checks COMPONENTS.md for correct UI component |
| `slow` | Claude stops reading logs, uses Sentry instead |
