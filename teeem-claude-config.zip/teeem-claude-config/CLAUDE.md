# TEEEM - Claude Code Instructions

## Golden Rule
**When uncertain, STOP and ask.** Never guess file locations, component names, or business logic.

## Before ANY Code Change
1. **Search first** - `grep -r "pattern" .` to find existing implementations
2. **If found in 2+ places** → STOP, show both, ask which is SSoT
3. **If UI work** → Read `TEEEM_DOCS/COMPONENTS.md` for THE ONE component
4. **If non-trivial** → State approach in 2 sentences before coding

## Verification (Do This Every Time)
After making changes, verify yourself:
```bash
# Check it compiles/lints
cd frontend-next && npm run typecheck
cd backend && bin/rails runner "puts 'OK'"
```
If either fails, fix before reporting done.

## Git Rules
- ❌ NEVER commit/push/deploy unless user says: "commit", "push", "deploy", "ship it", "/l"
- ✅ Make changes → let user test → wait for explicit approval

## When User Types These Keywords
| Keyword | You Missed | Action |
|---------|-----------|--------|
| `ssot` | Duplicate exists | Find both, ask which is truth |
| `ultra` | Lazy solution | Give 3 approaches, pick simplest |
| `gold` | Wrong component | Check TEEEM_DOCS/COMPONENTS.md |
| `slow` | Wasting tokens | Stop reading logs, use Sentry |

## Key Docs (Read When Relevant)
| Situation | Read First |
|-----------|-----------|
| Any table/UI work | `TEEEM_DOCS/COMPONENTS.md` |
| Column types | `TEEEM_DOCS/GOLD_STANDARD_TABLE.md` |
| Deployment | `TEEEM_DOCS/DEPLOY.md` |
| Debugging errors | `TEEEM_DOCS/DEBUGGING.md` |
| New feature planning | `.claude/skills/product-planner/SKILL.md` |

## API Format (Always)
```json
{"success": true, "data": {...}}
{"success": false, "error": "message"}
```

## Ports
- Frontend: 3000
- Backend: 3001

## Timezone
Always use `CompanySetting.in_company_timezone { }` in Ruby. Never raw `Date.today`.
