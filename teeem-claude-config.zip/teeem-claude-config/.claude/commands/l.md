---
description: Deploy backend to Heroku production (teeemlive)
---

Deploy the backend to production:

1. Check what changed:
```bash
git diff --name-only HEAD~1 HEAD | grep "^backend/" | head -10
```

2. If backend changes exist, deploy:
```bash
DEPLOY_DIR=$(mktemp -d)
cp -r backend/* "$DEPLOY_DIR/"
cd "$DEPLOY_DIR"
git init && git add . && git commit -m "Deploy $(date +%Y%m%d-%H%M%S)"
git remote add heroku https://git.heroku.com/teeemlive.git
git push heroku HEAD:main --force
cd - && rm -rf "$DEPLOY_DIR"
```

3. Show deployment summary with versions:
```bash
echo "========================================"
echo "DEPLOYED: $(TZ='Australia/Brisbane' date '+%H:%M %d/%m')"
echo "----------------------------------------"
curl -s https://teeemlive-ce8e2660a615.herokuapp.com/version | jq -r '.version' | xargs -I {} echo "Backend:  v{}"
cat frontend-next/package.json | jq -r '.version' | xargs -I {} echo "Frontend: v{}"
heroku releases --app teeemlive -n 1 | tail -1
echo "========================================"
```
