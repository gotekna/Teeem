# Deployment Guide

## Quick Deploy (Production)
```bash
/l
```
That's it. The `/l` command handles everything.

## Heroku Environments

| Environment | App | Branch | URL |
|-------------|-----|--------|-----|
| Production | `teeemlive` | Live | https://teeemlive.vercel.app |
| Rob Dev | `teeem-rob-dev` | Live | - |
| Sam Dev | `teeem-sam-dev` | - | - |

## Production URLs
- **Backend:** https://teeemlive-ce8e2660a615.herokuapp.com/
- **Frontend:** https://teeemlive.vercel.app/

## After Deploy - Always Show This
```
========================================
DEPLOYED: HH:MM DD/MM (Brisbane)
Commit: [hash] - [message]
----------------------------------------
Backend:  v[XXX] - [REQUIRED/not required]
Frontend: v[XXX] - [REQUIRED/not required]
Heroku:   [vXXX] - [deployed/skipped]
========================================
```

## Get Version Numbers
```bash
# Backend version
curl -s https://teeemlive-ce8e2660a615.herokuapp.com/version | jq -r '.version'

# Frontend version
cat frontend-next/package.json | jq -r '.version'

# Heroku release
heroku releases --app teeemlive -n 1

# Check if backend deploy needed
git diff --name-only HEAD~1 HEAD | grep -q "^backend/" && echo "REQUIRED" || echo "not required"
```

## Manual Deploy (Only if /l Broken)
```bash
# Fast orphan method - ~5 seconds, no memory issues
DEPLOY_DIR=$(mktemp -d)
cp -r backend/* "$DEPLOY_DIR/"
cd "$DEPLOY_DIR"
git init && git add . && git commit -m "Deploy $(date +%Y%m%d-%H%M%S)"
git remote add heroku https://git.heroku.com/teeemlive.git
git push heroku HEAD:main --force
cd - && rm -rf "$DEPLOY_DIR"
```

## Local Development

| Service | Port | Start Command |
|---------|------|---------------|
| Frontend | 3000 | `cd frontend-next && npm run dev` |
| Backend | 3001 | `cd backend && bin/rails server -p 3001` |

## Git Rules Reminder
- Rob works directly on `Live` branch
- Other devs use feature branches
- Never push without explicit user approval
